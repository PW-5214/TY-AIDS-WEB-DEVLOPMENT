const express = require('express');
const mongoose = require('mongoose');
const User = require('./models/User');

const app = express();
app.use(express.json());

//  MongoDB connection 
mongoose.connect('mongodb://localhost:27017/mydatabase')
  .then(() => console.log(' MongoDB connected'))
  .catch(err => console.log(' MongoDB connection error:', err));

//  GET all users
app.get('/users', async (req, res) => {
  const users = await User.find();
  res.json(users);
});

//  GET user by ID
app.get('/users/:id', async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json(user);
});

//  POST new user
app.post('/users', async (req, res) => {
  const newUser = new User(req.body);
  await newUser.save();
  res.status(201).json(newUser);
});

//  PUT update user
app.put('/users/:id', async (req, res) => {
  const updatedUser = await User.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!updatedUser) return res.status(404).json({ message: 'User not found' });
  res.json(updatedUser);
});

//  DELETE user
app.delete('/users/:id', async (req, res) => {
  const deletedUser = await User.findByIdAndDelete(req.params.id);
  if (!deletedUser) return res.status(404).json({ message: 'User not found' });
  res.json({ message: 'User deleted successfully' });
});

//  Start server
app.listen(3000, () => console.log('Server running on http://localhost:3000'));
